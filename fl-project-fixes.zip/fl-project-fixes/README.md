
# movies-explorer-frontend

Репозиторий для дипломного проекта `Веб-разработчик`, включающий бэкенд часть приложения со следующими возможностями: 

Адрес репозитория: https://github.com/InEmEcI/movies-explorer-frontend/tree/level-3


Макет Dark-1

Ссылка на пул реквест, открытый из ветки level-3 в main:
https://github.com/InEmEcI/movies-explorer-frontend/pull/2

Ссылка на задеплоенный на сервере проект:
https://nemec.nomoredomains.xyz

backend https://api.nemec.nomoredomains.xyz/

frontend https://nemec.nomoredomains.xyz