import { createContext, useState } from "react";
export const CurrentUserContext = createContext();

